package kg.geektech.game.logic;

public class Main {

    public static void main(String[] args) {
        RPG_Game.start();
    }
}
